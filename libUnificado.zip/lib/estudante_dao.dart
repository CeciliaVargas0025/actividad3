import 'package:actividad3/database_helper.dart';
import 'package:actividad3/estudante.dart';
import 'package:actividad3/disciplina.dart';
import 'package:actividad3/estudante_completo.dart'; // Añade esta importación
import 'package:sqflite/sqflite.dart';

class EstudanteDao {
  final Databasehelper _dbHelper = Databasehelper();

  Future<void> incluirEstudante(Estudante e, List<int> disciplinasIds) async {
    final db = await _dbHelper.database;
    await db.transaction((txn) async {
      // Insertar estudiante
      final id = await txn.insert(
        "estudante",
        e.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      
      // Insertar relaciones cursando
      for (var disciplinaId in disciplinasIds) {
        await txn.insert(
          "cursando",
          {"estudante_id": id, "disciplina_id": disciplinaId},
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
  }

  Future<void> editarEstudante(Estudante e, List<int> disciplinasIds) async {
    final db = await _dbHelper.database;
    await db.transaction((txn) async {
      // Actualizar estudiante
      await txn.update(
        "estudante",
        e.toMap(),
        where: "id = ?",
        whereArgs: [e.id],
      );
      
      // Eliminar relaciones antiguas
      await txn.delete(
        "cursando",
        where: "estudante_id = ?",
        whereArgs: [e.id],
      );
      
      // Insertar nuevas relaciones
      for (var disciplinaId in disciplinasIds) {
        await txn.insert(
          "cursando",
          {"estudante_id": e.id, "disciplina_id": disciplinaId},
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
  }

  Future<void> deleteEstudante(int id) async {
    final db = await _dbHelper.database;
    await db.transaction((txn) async {
      await txn.delete(
        "estudante",
        where: "id = ?",
        whereArgs: [id],
      );
      await txn.delete(
        "cursando",
        where: "estudante_id = ?",
        whereArgs: [id],
      );
    });
  }

  Future<List<Estudante>> listarEstudantes() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query("estudante");
    return List.generate(maps.length, (index) {
      return Estudante.fromMap(maps[index]);
    });
  }

  Future<EstudanteCompleto> obtenerEstudanteCompleto(int id) async {
    final db = await _dbHelper.database;
    final estudanteMap = (await db.query(
      "estudante",
      where: "id = ?",
      whereArgs: [id],
    )).first;

    final disciplinasMaps = await db.rawQuery('''
      SELECT disciplina.* FROM disciplina
      INNER JOIN cursando ON disciplina.id = cursando.disciplina_id
      WHERE cursando.estudante_id = ?
    ''', [id]);

    return EstudanteCompleto(
      estudante: Estudante.fromMap(estudanteMap),
      disciplinas: disciplinasMaps.map((map) => Disciplina.fromMap(map)).toList(),
    );
  }

  Future<List<Disciplina>> obtenerDisciplinasDisponibles() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query("disciplina");
    return List.generate(maps.length, (index) => Disciplina.fromMap(maps[index]));
  }
}