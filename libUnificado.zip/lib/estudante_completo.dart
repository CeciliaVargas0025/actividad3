import 'estudante.dart';
import 'disciplina.dart';

class EstudanteCompleto {
  final Estudante estudante;
  final List<Disciplina> disciplinas;

  EstudanteCompleto({
    required this.estudante,
    required this.disciplinas,
  });
}