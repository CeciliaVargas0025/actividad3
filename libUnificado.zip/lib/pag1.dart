import 'package:actividad3/estudante.dart';
import 'package:actividad3/estudante_dao.dart';
import 'package:actividad3/disciplina.dart';
import 'package:actividad3/estudante_completo.dart'; // Añade esta importación
import 'package:flutter/material.dart';

class Pag1 extends StatefulWidget {
  const Pag1({super.key});

  @override
  State<Pag1> createState() => _Pag1State();
}

class _Pag1State extends State<Pag1> {
  final _estudanteDAO = EstudanteDao();
  Estudante? _estudanteAtual;
  List<Disciplina> _disciplinasDisponibles = [];
  List<int> _disciplinasSeleccionadas = [];

  final _controllerNome = TextEditingController();
  final _controllerMatricula = TextEditingController();
  List<Estudante> _listaEstudantes = [];

  @override
  void initState() {
    _loadEstudantes();
    _loadDisciplinasDisponibles();
    super.initState();
  }

  _loadEstudantes() async {
    List<Estudante> temp = await _estudanteDAO.listarEstudantes();
    setState(() {
      _listaEstudantes = temp;
    });
  }

  _loadDisciplinasDisponibles() async {
    var temp = await _estudanteDAO.obtenerDisciplinasDisponibles();
    setState(() {
      _disciplinasDisponibles = temp;
    });
  }

  _salvarOUEditar() async {
    if (_estudanteAtual == null) {
      await _estudanteDAO.incluirEstudante(
        Estudante(
          nome: _controllerNome.text, 
          matricula: _controllerMatricula.text
        ),
        _disciplinasSeleccionadas,
      );
    } else {
      await _estudanteDAO.editarEstudante(
        Estudante(
          id: _estudanteAtual!.id,
          nome: _controllerNome.text, 
          matricula: _controllerMatricula.text
        ),
        _disciplinasSeleccionadas,
      );
    }
    
    _limpiarFormulario();
    _loadEstudantes();
  }

  _limpiarFormulario() {
    _controllerNome.clear();
    _controllerMatricula.clear();
    setState(() {
      _estudanteAtual = null;
      _disciplinasSeleccionadas = [];
    });
  }

  _cargarEstudanteParaEdicion(int id) async {
    var estudianteCompleto = await _estudanteDAO.obtenerEstudanteCompleto(id);
    setState(() {
      _estudanteAtual = estudianteCompleto.estudante;
      _controllerNome.text = estudianteCompleto.estudante.nome;
      _controllerMatricula.text = estudianteCompleto.estudante.matricula;
      _disciplinasSeleccionadas = estudianteCompleto.disciplinas.map((d) => d.id!).toList();
    });
  }

  _apagarEstudante(int id) async {
    await _estudanteDAO.deleteEstudante(id);
    _loadEstudantes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("CRUD Estudante con Disciplinas"),
        backgroundColor: Colors.cyan,
      ),
      body: Column(
        children: [
          // Formulario de estudiante
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _controllerNome,
              decoration: InputDecoration(
                labelText: "Nombre",
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _controllerMatricula,
              decoration: InputDecoration(
                labelText: "Matrícula",
                border: OutlineInputBorder(),
              ),
            ),
          ),
          
          // Selector de disciplinas
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Disciplinas:", style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height: 8),
                    _disciplinasDisponibles.isEmpty 
                      ? Center(child: CircularProgressIndicator())
                      : Wrap(
                          spacing: 8.0,
                          children: _disciplinasDisponibles.map((disciplina) {
                            return FilterChip(
                              label: Text("${disciplina.nome} (ID: ${disciplina.id})"),
                              selected: _disciplinasSeleccionadas.contains(disciplina.id),
                              onSelected: (selected) {
                                setState(() {
                                  if (selected) {
                                    _disciplinasSeleccionadas.add(disciplina.id!);
                                  } else {
                                    _disciplinasSeleccionadas.remove(disciplina.id);
                                  }
                                });
                              },
                            );
                          }).toList(),
                        ),
                  ],
                ),
              ),
            ),
          ),
          
          // Botones
          Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: _salvarOUEditar,
                    child: Text(_estudanteAtual == null ? "Guardar" : "Actualizar"),
                  ),
                ),
              ),
              if (_estudanteAtual != null)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ElevatedButton(
                      onPressed: _limpiarFormulario,
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
                      child: Text("Cancelar"),
                    ),
                  ),
                ),
            ],
          ),
          
          // Lista de estudiantes
          Expanded(
            child: ListView.builder(
              itemCount: _listaEstudantes.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: EdgeInsets.all(8),
                  child: ListTile(
                    title: Text(_listaEstudantes[index].nome),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Matrícula: ${_listaEstudantes[index].matricula}"),
                        FutureBuilder(
                          future: _estudanteDAO.obtenerEstudanteCompleto(_listaEstudantes[index].id!),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return Text("Cargando disciplinas...");
                            }
                            if (snapshot.hasError) return Text("Error al cargar disciplinas");
                            
                            final estudianteCompleto = snapshot.data as EstudanteCompleto;
                            final disciplinas = estudianteCompleto.disciplinas;
                            
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Disciplinas (${disciplinas.length}):"),
                                Wrap(
                                  spacing: 4.0,
                                  children: disciplinas.map((d) => Chip(
                                    label: Text("${d.nome} (ID: ${d.id})"),
                                    backgroundColor: Colors.blue[100],
                                  )).toList(),
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () => _cargarEstudanteParaEdicion(_listaEstudantes[index].id!),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _apagarEstudante(_listaEstudantes[index].id!),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}